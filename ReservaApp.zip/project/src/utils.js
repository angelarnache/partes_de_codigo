// Guarda el usuario en localStorage al iniciar sesión
export const saveSession = (user) => {
  localStorage.setItem("user", JSON.stringify(user));
};

// Obtiene el usuario guardado en localStorage
export const getSession = () => {
  return JSON.parse(localStorage.getItem("user"));
};

// Elimina el usuario de localStorage al cerrar sesión
export const removeSession = () => {
  localStorage.removeItem("user");
};

// Verifica si hay un usuario logueado
export const isAuthenticated = () => {
  return !!getSession();
};

// Verifica si el usuario logueado es admin
export const isAdmin = () => {
  return getSession()?.role === "admin";
};
