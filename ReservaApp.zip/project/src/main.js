import "@/style.css";
import { router } from "@/router/router";

// Arrancamos el router cuando el HTML esté completamente cargado
document.addEventListener("DOMContentLoaded", () => {
  router();
});
