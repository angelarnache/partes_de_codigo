// URL base del json-server
const API_URL = "http://localhost:3001";

// Función genérica para hacer fetch con manejo de errores
const request = async (endpoint, options = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });

    if (!response.ok) throw new Error(`HTTP Error ${response.status}`);

    // DELETE devuelve 200 vacío, no parseamos JSON en ese caso
    if (response.status === 200 && options.method === "DELETE") return true;

    return await response.json();
  } catch (error) {
    console.error("Error en request:", error);
    throw error;
  }
};

// Métodos HTTP exportados para usar en los servicios
export const http = {
  get: (endpoint) => request(endpoint),
  post: (endpoint, data) => request(endpoint, { method: "POST", body: JSON.stringify(data) }),
  put: (endpoint, data) => request(endpoint, { method: "PUT", body: JSON.stringify(data) }),
  patch: (endpoint, data) => request(endpoint, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (endpoint) => request(endpoint, { method: "DELETE" }),
};
