import { saveSession } from "@/utils";
import { navigateTo } from "@/router/router";
import { http } from "@/api/http";

// Controller del login: maneja el submit del formulario de autenticación
export const loginController = () => {
  const form = document.querySelector("#loginForm");
  const errorMsg = document.querySelector("#loginError");

  form.addEventListener("submit", async (e) => {
    e.preventDefault(); // Evita que la página se recargue

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    try {
      // Buscamos el usuario en json-server filtrando por email y password
      const users = await http.get(`/users?email=${email}&password=${password}`);

      if (!users.length) {
        // Si no hay coincidencia, mostramos el mensaje de error
        errorMsg.style.display = "block";
        return;
      }

      // Guardamos solo los datos necesarios en localStorage (no la contraseña)
      saveSession({
        id: users[0].id,
        name: users[0].name,
        role: users[0].role,
      });

      // Redirigimos según el rol
      if (users[0].role === "admin") {
        navigateTo("/admin");
      } else {
        navigateTo("/home");
      }

    } catch (error) {
      console.error("Error en login:", error);
      errorMsg.textContent = "Error conectando con el servidor";
      errorMsg.style.display = "block";
    }
  });
};
