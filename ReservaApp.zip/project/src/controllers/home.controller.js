import { getSession } from "@/utils";
import ReservationCard from "@/components/ReservationCard";
import {
  getReservationsByUser,
  createReservation,
  updateReservation,
  changeStatus,
} from "@/services/reservation.service";

// Controller del home del usuario: carga reservas y maneja CRUD del usuario
export const homeController = async () => {
  const user = getSession();
  const container = document.querySelector("#reservationsContainer");
  const formContainer = document.querySelector("#formContainer");
  const form = document.querySelector("#reservationForm");
  const formTitle = document.querySelector("#formTitle");
  const btnNueva = document.querySelector("#btnNuevaReserva");
  const btnCancelarForm = document.querySelector("#btnCancelarForm");

  // Función para cargar y mostrar las reservas del usuario
  const cargarReservas = async () => {
    const reservas = await getReservationsByUser(user.id);

    if (!reservas.length) {
      container.innerHTML = `<p style="color:#64748b;">No tienes reservas aún.</p>`;
      return;
    }

    // Renderizamos una tarjeta por cada reserva
    container.innerHTML = reservas.map(r => ReservationCard(r, user.id)).join("");

    // Adjuntamos eventos de editar en cada botón data-edit
    container.querySelectorAll("[data-edit]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-edit");
        const reserva = reservas.find(r => String(r.id) === id);
        abrirFormEditar(reserva); // Abre el form pre-rellenado
      });
    });

    // Adjuntamos eventos de cancelar en cada botón data-cancel
    container.querySelectorAll("[data-cancel]").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-cancel");
        if (confirm("¿Cancelar esta reserva?")) {
          // Solo cambiamos el estado a 'cancelled', no eliminamos
          await changeStatus(id, "cancelled");
          cargarReservas(); // Recargamos la lista
        }
      });
    });
  };

  // Abre el formulario en modo creación
  const abrirFormCrear = () => {
    formTitle.textContent = "Nueva Reserva";
    form.reset(); // Limpia todos los campos
    document.querySelector("#reservationId").value = ""; // Sin ID = crear
    formContainer.style.display = "block";
  };

  // Abre el formulario en modo edición con los datos de la reserva
  const abrirFormEditar = (reserva) => {
    formTitle.textContent = "Editar Reserva";
    document.querySelector("#reservationId").value = reserva.id;
    document.querySelector("#workspace").value = reserva.workspace;
    document.querySelector("#date").value = reserva.date;
    document.querySelector("#startHour").value = reserva.startHour;
    document.querySelector("#endHour").value = reserva.endHour;
    document.querySelector("#reason").value = reserva.reason;
    formContainer.style.display = "block";
  };

  // Botón "Nueva Reserva" abre el formulario vacío
  btnNueva.addEventListener("click", abrirFormCrear);

  // Botón "Cancelar" del formulario lo cierra
  btnCancelarForm.addEventListener("click", () => {
    formContainer.style.display = "none";
    form.reset();
  });

  // Submit del formulario: crea o edita según si hay ID
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const id = document.querySelector("#reservationId").value;

    // Construimos el objeto de reserva con los valores del form
    const datos = {
      userId: user.id,
      userName: user.name,
      workspace: document.querySelector("#workspace").value,
      date: document.querySelector("#date").value,
      startHour: document.querySelector("#startHour").value,
      endHour: document.querySelector("#endHour").value,
      reason: document.querySelector("#reason").value,
      status: "pending", // Toda reserva nueva o editada vuelve a pendiente
    };

    try {
      if (id) {
        // Si hay ID, actualizamos la reserva existente
        await updateReservation(id, { ...datos, id: Number(id) });
      } else {
        // Sin ID, creamos una nueva
        await createReservation(datos);
      }

      formContainer.style.display = "none";
      form.reset();
      cargarReservas(); // Recargamos para mostrar cambios

    } catch (error) {
      console.error("Error al guardar reserva:", error);
      alert("Error al guardar la reserva");
    }
  });

  // Cargamos las reservas al iniciar
  cargarReservas();
};
