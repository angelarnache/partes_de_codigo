import { http } from "@/api/http";

// Obtiene todas las reservas
export const getReservations = () => http.get("/reservations");

// Obtiene reservas de un usuario específico por su ID
export const getReservationsByUser = (userId) => http.get(`/reservations?userId=${userId}`);

// Crea una nueva reserva
export const createReservation = (data) => http.post("/reservations", data);

// Edita una reserva existente por su ID
export const updateReservation = (id, data) => http.put(`/reservations/${id}`, data);

// Cambia solo el estado de una reserva (patch parcial)
export const changeStatus = (id, status) => http.patch(`/reservations/${id}`, { status });

// Elimina una reserva por su ID
export const deleteReservation = (id) => http.delete(`/reservations/${id}`);
